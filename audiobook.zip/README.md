# audiobook
read any audio book using 12 lines of python


### Installation
To read PDF file using Python
` pip install pypdf2
`
To Read text (Text to speech)
` pip install pyaudio
`
` pip install pyttsx3
`

#### Note:
This code can read all the printable text from a PDF file/ Book
