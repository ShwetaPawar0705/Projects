# DINOSAUR GAME
This project is developed using C programming language. Only two buttons are used in the game; “x key” and “space bar”.
 X key to quit the game and Spacebar to jump. 
Play and score as much as you can, this is an interesting simple game developed specially for the beginners too and its easy to operate and understand by the users.

# IT WILL BE BETTER IF YOU RUN THIS CODE ON TURBO C++
thankyou!!!!!!!
